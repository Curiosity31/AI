Intelligenza artificiale - Algoritmo di Q-Learning

Sviluppo di comportamenti per un'interazione Uomo-Robot trasparente durante i processi di apprendimento.